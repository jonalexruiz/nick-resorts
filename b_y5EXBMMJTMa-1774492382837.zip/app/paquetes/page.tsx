
"use client"

import Image from "next/image"
import { useContext, useState } from "react"
import { Star, Users, Wifi, Utensils, Dumbbell, Wind } from "lucide-react"
import { ReservationContext } from "@/context/reservation-context"

export default function PaquetesPage() {
  const { setIsOpen } = useContext(ReservationContext)

  const [calculator, setCalculator] = useState({
    room: "deluxe",
    package: "todo-incluido",
    nights: 7,
    adults: 2,
    kids: 0,
  })

  const rooms = [
    {
      id: "presidential",
      name: "Suite Presidencial Nick",
      size: "120m²",
      capacity: "4 adultos + 2 niños",
      basePrice: 599,
      image: "/room-presidential.jpg",
      amenities: ["Jacuzzi privado", "Cocina completa", "Terraza", "Slime party privada"],
      description: "Suite de lujo con vista al mar y amenidades premium",
    },
    {
      id: "spongebob",
      name: "Suite Familiar SpongeBob",
      size: "85m²",
      capacity: "4 adultos + 2 niños",
      basePrice: 399,
      image: "/room-spongebob.jpg",
      amenities: ["Temática exclusiva", "Juegos interactivos", "Baño temático", "Smart TV"],
      description: "Habitación temática con experiencia interactiva de Bob Esponja",
    },
    {
      id: "paw-patrol",
      name: "Suite Deluxe PAW Patrol",
      size: "70m²",
      capacity: "3 adultos + 2 niños",
      basePrice: 329,
      image: "/room-paw-patrol.jpg",
      amenities: ["Zona de juegos", "Cama temática", "Decoración PAW Patrol", "Minibar"],
      description: "Suite aventurera con temática de PAW Patrol",
    },
    {
      id: "ocean-view",
      name: "Junior Suite Ocean View",
      size: "50m²",
      capacity: "2 adultos + 1 niño",
      basePrice: 249,
      image: "/room-ocean-view.jpg",
      amenities: ["Balcón con vista al mar", "Minibar premium", "Aire acondicionado", "Safe"],
      description: "Elegante suite con hermosa vista al océano",
    },
  ]

  const packages = [
    {
      id: "todo-incluido",
      name: "Todo Incluido Plus",
      price: 2499,
      nights: 7,
      image: "/package-spa.jpg",
      benefits: ["Habitación Deluxe", "Spa incluido", "Excursión a Isla Saona", "Bebidas premium"],
    },
    {
      id: "familiar",
      name: "Pack Familiar Aventura",
      price: 3299,
      nights: 7,
      image: "/package-family.jpg",
      benefits: ["Suite familiar", "Meet & Greet con personajes", "Pase parque acuático", "Actividades diarias"],
    },
    {
      id: "luna-miel",
      name: "Luna de Miel",
      price: 2899,
      nights: 5,
      image: "/package-honeymoon.jpg",
      benefits: ["Suite Presidencial", "Cena romántica en playa", "Masaje para parejas", "Champagne"],
    },
    {
      id: "slime",
      name: "Pack Slime Extreme",
      price: 1899,
      nights: 5,
      image: "/package-slime.jpg",
      benefits: ["Experiencia slime diaria", "Camiseta exclusiva", "Fiesta slime familiar", "Kit DIY"],
    },
  ]

  const roomData = rooms.find((r) => r.id === calculator.room)
  const nightPrice = roomData?.basePrice || 0
  const packagePrice = calculator.package ? packages.find((p) => p.id === calculator.package)?.price || 0 : 0
  const totalPrice = nightPrice * calculator.nights + packagePrice

  return (
    <main className="bg-background">
      {/* Header */}
      <section className="relative py-20 px-4 bg-gradient-to-r from-[#FF6B00]/20 to-[#3DB54A]/20">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-black text-foreground mb-4 font-display">
            Habitaciones y Paquetes
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Elige el alojamiento perfecto y personaliza tu experiencia Nick Resorts
          </p>
        </div>
      </section>

      {/* Rooms Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-black text-foreground mb-12 text-center font-display">
            Habitaciones Elegantes
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {rooms.map((room) => (
              <div
                key={room.id}
                className="group bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300"
              >
                <div className="relative h-64 overflow-hidden bg-gray-200">
                  <Image
                    src={room.image}
                    alt={room.name}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-[#FF6B00] text-white px-4 py-2 rounded-full font-bold text-sm">
                    ${room.basePrice}/noche
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-2 font-display">{room.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{room.description}</p>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-sm">
                      <Wind className="w-4 h-4 text-[#FF6B00]" />
                      <span className="text-gray-700">{room.size}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="w-4 h-4 text-[#FF6B00]" />
                      <span className="text-gray-700">{room.capacity}</span>
                    </div>
                  </div>

                  <div className="mb-6">
                    <p className="text-xs font-bold text-gray-600 mb-2">AMENIDADES:</p>
                    <div className="flex flex-wrap gap-2">
                      {room.amenities.map((amenity) => (
                        <span key={amenity} className="text-xs bg-gray-100 text-gray-700 px-3 py-1 rounded-full">
                          {amenity}
                        </span>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => setIsOpen(true)}
                    className="w-full bg-[#FF6B00] text-white font-bold py-3 rounded-lg hover:bg-[#E55A00] transition-colors duration-200"
                  >
                    RESERVAR
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-[#3DB54A]/10 to-[#FF6B00]/10">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-black text-foreground mb-12 text-center font-display">
            Paquetes Especiales
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {packages.map((pkg) => (
              <div
                key={pkg.id}
                className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 border-2 border-[#FF6B00]/20"
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={pkg.image}
                    alt={pkg.name}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                    <div className="p-4 w-full">
                      <h3 className="text-2xl font-bold text-white font-display">{pkg.name}</h3>
                      <p className="text-[#FF6B00] font-bold">${pkg.price} • {pkg.nights} noches</p>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <div className="mb-6">
                    <p className="text-xs font-bold text-gray-600 mb-3">BENEFICIOS INCLUIDOS:</p>
                    <ul className="space-y-2">
                      {pkg.benefits.map((benefit) => (
                        <li key={benefit} className="flex items-start gap-2 text-sm text-gray-700">
                          <Star className="w-4 h-4 text-[#FF6B00] mt-0.5 shrink-0" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <button
                    onClick={() => setIsOpen(true)}
                    className="w-full bg-[#FF6B00] text-white font-bold py-3 rounded-lg hover:bg-[#E55A00] transition-colors duration-200"
                  >
                    RESERVAR PAQUETE
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Calculator Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-black text-foreground mb-8 text-center font-display">
            Calculadora de Presupuesto
          </h2>
          <div className="bg-gradient-to-br from-[#FF6B00]/10 to-[#3DB54A]/10 p-8 rounded-2xl">
            <div className="space-y-6">
              {/* Room Selection */}
              <div>
                <label className="block text-sm font-bold text-foreground mb-2">Seleccionar Habitación</label>
                <select
                  value={calculator.room}
                  onChange={(e) => setCalculator({ ...calculator, room: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-foreground font-medium"
                >
                  {rooms.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name} (${r.basePrice}/noche)
                    </option>
                  ))}
                </select>
              </div>

              {/* Package Selection */}
              <div>
                <label className="block text-sm font-bold text-foreground mb-2">Paquete Especial (Opcional)</label>
                <select
                  value={calculator.package}
                  onChange={(e) => setCalculator({ ...calculator, package: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-foreground font-medium"
                >
                  <option value="">Sin paquete</option>
                  {packages.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (+${p.price})
                    </option>
                  ))}
                </select>
              </div>

              {/* Night, Adults, Kids */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-bold text-foreground mb-2">Noches</label>
                  <input
                    type="number"
                    min="1"
                    max="14"
                    value={calculator.nights}
                    onChange={(e) => setCalculator({ ...calculator, nights: Math.min(14, Math.max(1, parseInt(e.target.value) || 1)) })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-foreground font-medium text-center"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-foreground mb-2">Adultos</label>
                  <input
                    type="number"
                    min="1"
                    max="8"
                    value={calculator.adults}
                    onChange={(e) => setCalculator({ ...calculator, adults: Math.min(8, Math.max(1, parseInt(e.target.value) || 1)) })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-foreground font-medium text-center"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-foreground mb-2">Niños</label>
                  <input
                    type="number"
                    min="0"
                    max="6"
                    value={calculator.kids}
                    onChange={(e) => setCalculator({ ...calculator, kids: Math.min(6, Math.max(0, parseInt(e.target.value) || 0)) })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-foreground font-medium text-center"
                  />
                </div>
              </div>

              {/* Price Display */}
              <div className="bg-white border-2 border-[#FF6B00] rounded-xl p-6 text-center">
                <p className="text-gray-600 text-sm mb-2">Precio Total</p>
                <p className="text-4xl font-black text-[#FF6B00] font-display">${totalPrice.toLocaleString()}</p>
                <p className="text-gray-600 text-xs mt-2">
                  {roomData?.basePrice} x {calculator.nights} noches{calculator.package ? " + paquete" : ""}
                </p>
              </div>

              {/* Reserve Button */}
              <button
                onClick={() => setIsOpen(true)}
                className="w-full bg-[#FF6B00] text-white font-bold py-4 rounded-lg hover:bg-[#E55A00] transition-colors duration-200 text-lg"
              >
                Solicitar Reserva
              </button>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
