"use client"

import { Facebook, Instagram, Music, Youtube, Send } from "lucide-react"
import { useState } from "react"

const destinations = [
  { name: "Punta Cana", href: "#" },
  { name: "Riviera Maya", href: "#" },
  { name: "Próximamente: Los Cabos", href: "#", disabled: true },
]

const quickLinks = [
  { name: "Inicio", href: "/" },
  { name: "Restaurantes", href: "/restaurantes" },
  { name: "Paquetes", href: "/paquetes" },
  { name: "Experiencias", href: "#" },
  { name: "Contacto", href: "#" },
]

const socialLinks = [
  { icon: Facebook, label: "Facebook", href: "#" },
  { icon: Instagram, label: "Instagram", href: "#" },
  { icon: Music, label: "TikTok", href: "#" },
  { icon: Youtube, label: "YouTube", href: "#" },
]

const footerLinks = [
  { name: "Política de privacidad", href: "#" },
  { name: "Términos y condiciones", href: "#" },
]

export function Footer() {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim()) {
      setSubscribed(true)
      setEmail("")
      setTimeout(() => setSubscribed(false), 3000)
    }
  }

  return (
    <footer className="bg-[#1a1a1a] text-white">
      {/* Main content */}
      <div className="max-w-6xl mx-auto px-4 py-16 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-8">
          {/* Column 1 — Logo & Description */}
          <div className="flex flex-col gap-4">
            <h3
              className="text-2xl font-black text-[#FF6B00] leading-tight"
              style={{ fontFamily: "var(--font-display, 'Montserrat', sans-serif)" }}
            >
              NICK RESORTS
            </h3>
            <p className="text-sm text-gray-300 leading-relaxed">
              Lujo y diversión sin límites en el Caribe
            </p>
          </div>

          {/* Column 2 — Destinations */}
          <div className="flex flex-col gap-4">
            <h4
              className="text-sm font-black uppercase tracking-wider text-white"
              style={{ fontFamily: "var(--font-display, 'Montserrat', sans-serif)" }}
            >
              Destinos
            </h4>
            <nav aria-label="Destinos" className="flex flex-col gap-2.5">
              {destinations.map((dest) => (
                <a
                  key={dest.name}
                  href={dest.href}
                  className={`
                    text-sm transition-colors duration-200
                    ${
                      dest.disabled
                        ? "text-gray-500 cursor-not-allowed"
                        : "text-gray-300 hover:text-[#FF6B00]"
                    }
                  `}
                >
                  {dest.name}
                </a>
              ))}
            </nav>
          </div>

          {/* Column 3 — Quick Links */}
          <div className="flex flex-col gap-4">
            <h4
              className="text-sm font-black uppercase tracking-wider text-white"
              style={{ fontFamily: "var(--font-display, 'Montserrat', sans-serif)" }}
            >
              Enlaces Rápidos
            </h4>
            <nav aria-label="Enlaces rápidos" className="flex flex-col gap-2.5">
              {quickLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-sm text-gray-300 hover:text-[#FF6B00] transition-colors duration-200"
                >
                  {link.name}
                </a>
              ))}
            </nav>
          </div>

          {/* Column 4 — Social & Newsletter */}
          <div className="flex flex-col gap-6">
            {/* Social Icons */}
            <div className="flex flex-col gap-4">
              <h4
                className="text-sm font-black uppercase tracking-wider text-white"
                style={{ fontFamily: "var(--font-display, 'Montserrat', sans-serif)" }}
              >
                Síguenos
              </h4>
              <div className="flex gap-3">
                {socialLinks.map((social) => {
                  const Icon = social.icon
                  return (
                    <a
                      key={social.label}
                      href={social.href}
                      aria-label={`Seguir en ${social.label}`}
                      className="
                        w-10 h-10 rounded-full bg-gray-800 text-gray-300
                        flex items-center justify-center
                        hover:bg-[#FF6B00] hover:text-white
                        transition-colors duration-200
                        focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF6B00]
                      "
                    >
                      <Icon className="w-5 h-5" aria-hidden="true" />
                    </a>
                  )
                })}
              </div>
            </div>

            {/* Newsletter */}
            <form
              onSubmit={handleNewsletterSubmit}
              className="flex flex-col gap-2"
              aria-label="Suscripción a newsletter"
            >
              <label htmlFor="newsletter-email" className="text-xs font-semibold uppercase tracking-wider text-white/80">
                Newsletter
              </label>
              <div className="flex gap-2">
                <input
                  id="newsletter-email"
                  type="email"
                  placeholder="Tu email..."
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="
                    flex-1 px-4 py-2.5 rounded-full
                    bg-gray-800 text-white placeholder-gray-500
                    text-sm
                    border border-gray-700 hover:border-gray-600 focus:border-[#FF6B00]
                    focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[#FF6B00]
                    transition-colors duration-200
                  "
                  required
                />
                <button
                  type="submit"
                  className="
                    shrink-0 w-10 h-10 rounded-full
                    bg-[#FF6B00] text-white
                    flex items-center justify-center
                    hover:bg-[#E55A00]
                    transition-colors duration-200
                    focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF6B00]
                  "
                  aria-label="Suscribirse al newsletter"
                >
                  <Send className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
              {subscribed && (
                <p className="text-xs text-[#3DB54A] font-medium">¡Gracias por suscribirte!</p>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-gray-800" />

      {/* Bottom section — Copyright & Links */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <p className="text-sm text-gray-400">
            © 2025 Nickelodeon Resorts. Todos los derechos reservados.
          </p>
          <nav aria-label="Políticas" className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
            {footerLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm text-gray-400 hover:text-[#FF6B00] transition-colors duration-200"
              >
                {link.name}
              </a>
            ))}
          </nav>
        </div>
      </div>
    </footer>
  )
}
